"""
Student Expense Tracker GUI Application
----------------------------------------
Purpose:
This application allows students to track, manage, save, and load their daily expenses.
It uses a multi-window Tkinter GUI interface with secure input validation.

Author: Isaac Thompson
Course: Python tkinter GUI Final Project
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import json
from datetime import datetime


# ==========================================================
# MODULE: MainApplication
# Purpose:
# Controls the main window, layout, navigation,
# and connects all major application features.
# ==========================================================

class MainApplication:

    def __init__(self, root):
        """Initialize main window and all variables."""
        self.root = root                      # Main Tkinter window
        self.root.title("Student Expense Tracker")
        self.root.geometry("800x600")

        self.expenses = []                    # List to store all expense records

        self.create_menu()                    # Create menu bar
        self.create_widgets()                 # Create main interface

    # ------------------------------------------------------
    # Create Menu Bar
    # ------------------------------------------------------
    def create_menu(self):
        """Creates File and Help menus."""
        menubar = tk.Menu(self.root)

        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="Save", command=self.save_data)
        file_menu.add_command(label="Load", command=self.load_data)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        menubar.add_cascade(label="File", menu=file_menu)

        help_menu = tk.Menu(menubar, tearoff=0)
        help_menu.add_command(label="About", command=self.open_about_window)
        menubar.add_cascade(label="Help", menu=help_menu)

        self.root.config(menu=menubar)

    # ------------------------------------------------------
    # Create Main Widgets
    # ------------------------------------------------------
    def create_widgets(self):
        """Creates labels, buttons, entry fields, and treeview."""

        # ========== Labels ==========
        title_label = tk.Label(self.root, text="Student Expense Tracker",
                               font=("Arial", 18, "bold"))
        title_label.pack(pady=10)

        entry_label = tk.Label(self.root, text="Enter Expense Information")
        entry_label.pack()

        # ========== Entry Section ==========
        entry_frame = tk.Frame(self.root)
        entry_frame.pack(pady=10)

        tk.Label(entry_frame, text="Amount ($):").grid(row=0, column=0)
        self.amount_entry = tk.Entry(entry_frame)
        self.amount_entry.grid(row=0, column=1)

        tk.Label(entry_frame, text="Category:").grid(row=1, column=0)
        self.category_box = ttk.Combobox(entry_frame,
                                         values=["Food", "Transport",
                                                 "Entertainment", "School", "Other"])
        self.category_box.grid(row=1, column=1)

        tk.Label(entry_frame, text="Date (YYYY-MM-DD):").grid(row=2, column=0)
        self.date_entry = tk.Entry(entry_frame)
        self.date_entry.grid(row=2, column=1)

        # ========== Buttons ==========
        add_button = tk.Button(self.root, text="Add Expense",
                               command=self.add_expense)
        add_button.pack(pady=5)

        delete_button = tk.Button(self.root, text="Delete Selected",
                                  command=self.delete_expense)
        delete_button.pack(pady=5)

        exit_button = tk.Button(self.root, text="Exit",
                                command=self.root.quit)
        exit_button.pack(pady=5)

        # ========== TreeView ==========
        self.tree = ttk.Treeview(self.root,
                                 columns=("Amount", "Category", "Date"),
                                 show="headings")

        self.tree.heading("Amount", text="Amount")
        self.tree.heading("Category", text="Category")
        self.tree.heading("Date", text="Date")

        self.tree.pack(expand=True, fill="both")

        # ========== Summary Label ==========
        self.total_label = tk.Label(self.root, text="Total: $0.00")
        self.total_label.pack(pady=5)

    # ------------------------------------------------------
    # Add Expense (Callback Function)
    # ------------------------------------------------------
    def add_expense(self):
        """
        Validates user input and adds expense to list and table.
        Implements secure coding best practices.
        """

        amount = self.amount_entry.get().strip()
        category = self.category_box.get().strip()
        date = self.date_entry.get().strip()

        # --- Validation ---
        if not amount or not category or not date:
            messagebox.showerror("Input Error", "All fields are required.")
            return

        try:
            amount = float(amount)
            if amount <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Input Error",
                                 "Amount must be a positive number.")
            return

        try:
            datetime.strptime(date, "%Y-%m-%d")
        except ValueError:
            messagebox.showerror("Input Error",
                                 "Date must be in YYYY-MM-DD format.")
            return

        expense = {"amount": amount,
                   "category": category,
                   "date": date}

        self.expenses.append(expense)

        self.tree.insert("", "end",
                         values=(amount, category, date))

        self.update_total()

        self.amount_entry.delete(0, tk.END)

    # ------------------------------------------------------
    # Delete Expense
    # ------------------------------------------------------
    def delete_expense(self):
        """Deletes selected expense from list and GUI."""

        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Warning", "Select an item first.")
            return

        for item in selected:
            index = self.tree.index(item)
            self.tree.delete(item)
            del self.expenses[index]

        self.update_total()

    # ------------------------------------------------------
    # Update Total Summary
    # ------------------------------------------------------
    def update_total(self):
        """Calculates and updates total expenses."""
        total = sum(exp["amount"] for exp in self.expenses)
        self.total_label.config(text=f"Total: ${total:.2f}")

    # ------------------------------------------------------
    # Save Data
    # ------------------------------------------------------
    def save_data(self):
        """Saves expenses securely to JSON file."""
        file_path = filedialog.asksaveasfilename(defaultextension=".json")
        if file_path:
            with open(file_path, "w") as file:
                json.dump(self.expenses, file)

    # ------------------------------------------------------
    # Load Data
    # ------------------------------------------------------
    def load_data(self):
        """Loads expense data from JSON file."""
        file_path = filedialog.askopenfilename(filetypes=[("JSON", "*.json")])
        if file_path:
            with open(file_path, "r") as file:
                self.expenses = json.load(file)

            self.tree.delete(*self.tree.get_children())

            for exp in self.expenses:
                self.tree.insert("", "end",
                                 values=(exp["amount"],
                                         exp["category"],
                                         exp["date"]))

            self.update_total()

    # ------------------------------------------------------
    # Second Window (About Window)
    # ------------------------------------------------------
    def open_about_window(self):
        """Creates second window with application information."""
        about_window = tk.Toplevel(self.root)
        about_window.title("About")
        about_window.geometry("400x200")

        tk.Label(about_window,
                 text="Student Expense Tracker",
                 font=("Arial", 14, "bold")).pack(pady=10)

        tk.Label(about_window,
                 text="This application helps students\n"
                      "track and manage expenses easily.").pack(pady=5)

        tk.Button(about_window,
                  text="Close",
                  command=about_window.destroy).pack(pady=10)


# ==========================================================
# MAIN PROGRAM ENTRY POINT
# ==========================================================
if __name__ == "__main__":
    root = tk.Tk()
    app = MainApplication(root)
    root.mainloop()